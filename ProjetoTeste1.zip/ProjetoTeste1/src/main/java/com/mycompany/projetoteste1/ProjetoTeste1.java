
// ProjetoTeste1.java 

package com.mycompany.projetoteste1;

public class ProjetoTeste1 {

    // Método para realizar a adição
    public  double adicao(double a, double b) {
        return a + b;
    }

    // Método para realizar a subtração
    public  double subtracao(double a, double b) {
        return a - b;
    }

    // Método para realizar a multiplicação
    public double multiplicacao(double a, double b) {
        return a * b;
    }

    // Método para realizar a divisão
    public int divisao(int a, int b) {          
        return a / b;
    }
    
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
