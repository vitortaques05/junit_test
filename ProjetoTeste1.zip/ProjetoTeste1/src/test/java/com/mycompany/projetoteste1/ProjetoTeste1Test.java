
package com.mycompany.projetoteste1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Aluno TDS
 */
public class ProjetoTeste1Test {
   
    ProjetoTeste1 proj = new ProjetoTeste1();
    
    @Test
    public void testAdicao() {
        assertEquals(15, proj.adicao(10, 5));
    }

    @Test
    public void testSubtracao() {
        assertEquals(5, proj.subtracao(10, 5));
    }

    @Test
    public void testMultiplicacao() {
        assertEquals(50, proj.multiplicacao(10, 5));
    }

    @Test
    public void testDivisaoPorZero() {
       proj.divisao(10, 0);
    }

   
}
